# PRV1 / Issue #21 -- closure evidence report

Status key: DONE = evidence attached. PARTIAL = evidence exists but does not meet the reviewer's wording. OPEN = not done.

| # | Reviewer requirement | Status | Evidence file |
|---|---|---|---|
| 1 | Composition test output, Path-A vs Path-B, strict inequality | DONE | 01_composition_test_output.txt (A=4.9901; B r1=3.5992, r2=4.9939) |
| 2 | Duplicate-seed determinism, every client within +/-0.01 | DONE | 02_determinism_test_output.txt (max diff 0.000000) |
| 3 | Production-path audit: no PrivacyEngine(...) in per-round code; same engine reused all rounds | DONE, with one open check | 03_production_path_audit.txt. Engine reuse shown by call-site structure plus rising cumulative epsilon (06); direct id(engine) log skipped with maintainer approval. Open: confirm docker_bench_client.py (2 copies) is not imported by the pipeline. |
| 4 | USE_DP=False regression, no engine, BatchNorm + standard LSTM unchanged | DONE | 04_nodp_regression_output.txt (0 engines, BatchNorm1d + LSTM) |
| 5 | Corrected 19-point full-run epsilon sweep | **OPEN / PARTIAL** | 05_manifest_audit_summary.txt: 7 of 19 points run {0.2, 0.5, 1, 3, 5, 10, 15}. Missing 12: 0.3, 0.4, 0.6, 0.7, 0.8, 0.9, 2, 4, 6, 7, 8, 9. E4_dense_epsilon_sweep.json not verified. |
| 6 | Manifest audit of corrected DP runs | DONE for existing runs | 05_manifest_audit.csv, 05_manifest_audit_summary.txt (24/24 pass), 06_cumulative_epsilon_per_round_check.csv |

## Items that must be resolved before the issue is closed
1. Item 5: either run the 12 missing points, or get the maintainer's written confirmation that acceptance item 4 means the config list and not execution of the sweep. The reviewer's comment explicitly says not to reduce this requirement.
2. Verify E4_dense_epsilon_sweep.json lists exactly the 19 values.
3. Confirm docker_bench_client.py is standalone (dir /s /b docker_bench_client.py ; findstr /s /n "docker_bench_client" *.py).

## Caveats to state honestly in the issue comment
- Composition test margin vs Path A is only 0.0038; the accumulation is shown by round 1 -> round 2 (3.5992 -> 4.9939).
- Determinism: epsilon is computed from noise multiplier, sample rate and steps, so a zero diff does not prove the noise sampler is seeded.
- Two e4b runs overshoot the target slightly (seed 456 +0.568%, seed 2024 +0.403%); all E4 runs are at or just under target.
- Adaptive and Calibrated Krum share identical epsilon at each target: 14 E4 files = 7 independent calibrations, single seed 42.
- The USE_DP=False construction counter runs in the main process only; the proof rests on build_dp_client_states() being the only constructor and being reachable only under USE_DP=True.
