# Issue #23 evidence bundle (post-hoc, assembled from the files available on 2026-10-10)

Reproduce all derived tables:  `pip install pandas scipy numpy && python scripts/recompute_evidence.py`
(writes `derived/`; verified to reproduce the tables quoted in the closing comment).

| Folder | Contents | Supports (comment section) |
|---|---|---|
| `task1_sanity/` | 6 per-client Krum score CSVs + results CSVs, seed 42 | 1 (Task 1) |
| `mu_validation/` | 60 FINAL_VALIDATION CSVs (2 models x [FedAvg + 5 mu] x 5 seeds) | 2 (FedProx mu) |
| `e5_param_sensitivity/` | 100 per-client CSVs + available results CSVs, Tables A/B (5 seeds) | 3 (Tables A/B) |
| `e6_unverified/` | E6 analysis summary ONLY - raw per-run files not available | 4 (ablation) - NOT VERIFIED |
| `scripts/` | launchers (`run_e6.sh`, `run_task5_*`, `run_task4_*`), `summarize_e6.py`, `recompute_evidence.py` | 2,3,4 provenance |
| `tests/` | `test_calibrated_krum.py` + output of an independent run (2 passed) | 7 |
| `derived/` | regenerated summary tables (Task 1, mu, Table A, Table B, seed-level) | 1,2,3 |
| `SHA256SUMS.txt` | hash of every file | traceability |

Not included on purpose: `krum.py` / `main.py` (commit the final versions, with the
stale unit-note docstring removed, in the repo instead). See `MISSING_ITEMS.md`.
