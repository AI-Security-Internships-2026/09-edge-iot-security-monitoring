#!/usr/bin/env python3
"""Regenerates the closure-evidence tables for Issue #23 from the raw CSVs in
this bundle. Usage (from the bundle root):  python scripts/recompute_evidence.py
Writes to ./derived/. Honest-FPR = FP/(FP+TN) over honest client-rounds;
Byzantine-TPR = TP/(TP+FN) over Byzantine client-rounds (pooled over rounds,
then mean over seeds). CI = two-sided 95% t-interval half-width over seeds."""
import glob, os, re
import numpy as np, pandas as pd
from scipy import stats

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "derived"); os.makedirs(OUT, exist_ok=True)

def ci(x):
    x = np.asarray(x, float); n = len(x)
    return float(stats.t.ppf(.975, n - 1) * x.std(ddof=1) / np.sqrt(n)) if n > 1 else np.nan

def fpr_tpr(path):
    d = pd.read_csv(path)
    h = d[d.ground_truth_client_label == "honest"]; b = d[d.ground_truth_client_label != "honest"]
    return (h.classification == "FP").mean(), (b.classification == "TP").mean(), len(h), len(b), d

# ---- Task 1
rows = []
for f in sorted(glob.glob(os.path.join(ROOT, "task1_sanity", "per_client_krum_scores_*.csv"))):
    a, e = re.search(r"sanity_a(\d+)_eps(\w+?)_seed", f).groups()
    fpr, tpr, nh, nb, d = fpr_tpr(f)
    rows.append(dict(alpha={"10": 10, "07": 0.7, "03": 0.3}[a], epsilon="none" if e == "None" else e.replace("eps", ""),
                     seed=42, honest_fp=int(round(fpr * nh)), honest_client_rounds=nh, honest_fpr=round(fpr, 4),
                     byz_tpr=round(tpr, 3), rounds_present=f"{int(d.round_id.min())}-{int(d.round_id.max())}",
                     partial_rounds=nh < 200))
pd.DataFrame(rows).sort_values(["epsilon", "alpha"], ascending=[True, False]).to_csv(os.path.join(OUT, "Task1_sanity_summary.csv"), index=False)

# ---- E5 Table A / B
rows = []
for f in glob.glob(os.path.join(ROOT, "e5_param_sensitivity", "per_client_krum_scores_network_task5_*.csv")):
    sw, ag, val, seed = re.search(r"task5_(madk|fsweep)_(plain|calibrated)_[kf]([0-9.]+)_seed(\d+)", f).groups()
    fpr, tpr, nh, nb, _ = fpr_tpr(f)
    rows.append(dict(sweep=sw, aggregator=ag, param=float(val), seed=int(seed), honest_fpr=fpr, byz_tpr=tpr,
                     honest_client_rounds=nh, byz_client_rounds=nb))
r = pd.DataFrame(rows).sort_values(["sweep", "param", "aggregator", "seed"])
r.to_csv(os.path.join(OUT, "E5_seed_level_fpr_tpr.csv"), index=False)
for sw, name, col in [("madk", "TableA_madk.csv", "k"), ("fsweep", "TableB_fsweep.csv", "f")]:
    out = []
    for pm in sorted(r[r.sweep == sw].param.unique()):
        c = r[(r.sweep == sw) & (r.param == pm) & (r.aggregator == "calibrated")]
        p = r[(r.sweep == sw) & (r.param == pm) & (r.aggregator == "plain")]
        out.append({col: pm, "n_seeds": len(c), "cal_honest_fpr_mean": c.honest_fpr.mean(), "cal_fpr_ci95": ci(c.honest_fpr),
                    "plain_honest_fpr_mean": p.honest_fpr.mean(), "plain_fpr_ci95": ci(p.honest_fpr),
                    "delta_fpr(plain-cal)": p.honest_fpr.mean() - c.honest_fpr.mean(),
                    "cal_byz_tpr_mean": c.byz_tpr.mean(), "cal_tpr_ci95": ci(c.byz_tpr),
                    "plain_byz_tpr_mean": p.byz_tpr.mean(), "plain_tpr_ci95": ci(p.byz_tpr),
                    "tpr_gap_pp(plain-cal)": 100 * (p.byz_tpr.mean() - c.byz_tpr.mean())})
    pd.DataFrame(out).round(4).to_csv(os.path.join(OUT, name), index=False)

# ---- mu validation
rows = []
for f in glob.glob(os.path.join(ROOT, "mu_validation", "*_FINAL_VALIDATION.csv")):
    m = re.search(r"results_(network|application)_task4_(fedprox_mu([0-9.]+)|fedavg)_seed(\d+)_", f)
    d = pd.read_csv(f); col = [c for c in d.columns if "f1_macro" in c][0]
    rows.append(dict(model=m.group(1), method="fedavg" if m.group(2) == "fedavg" else "fedprox",
                     mu=np.nan if m.group(3) is None else float(m.group(3)), seed=int(m.group(4)), val_macro_f1=float(d[col].iloc[0])))
v = pd.DataFrame(rows).sort_values(["model", "method", "mu", "seed"]); v.to_csv(os.path.join(OUT, "mu_validation_seed_level.csv"), index=False)
fp = v[v.method == "fedprox"]
s = fp.groupby(["model", "mu"]).val_macro_f1.agg(["mean", "std", "count"]).reset_index()
s["ci95"] = [ci(fp[(fp.model == a) & (fp.mu == b)].val_macro_f1) for a, b in zip(s.model, s.mu)]
s["selected"] = s.groupby("model")["mean"].transform("max") == s["mean"]
s.round(4).to_csv(os.path.join(OUT, "mu_validation_summary.csv"), index=False)
print("wrote", sorted(os.listdir(OUT)))
