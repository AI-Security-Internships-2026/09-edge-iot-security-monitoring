# Not in this bundle (needed before closure; marked PENDING in the comment)
- E6 raw per-run files (per_client_krum_scores / results FINAL_TEST / dp_final_epsilon JSON for e6_full, e6_dponly, e6_heteroonly, e6_off x 5 seeds) -> then run scripts/summarize_e6.py
- hetero_fit_coeffs.json (check fit_target, schema_version=2), scripts/fit_hetero_variance.py, its input CSV and fit log
- experiments/configs/E6_frozen_bounded_tau.json
- E5 per-run experiment_config / manifests (attack type, hetero-fit flag, git SHA); the ~12-14 missing E5 FINAL_TEST/VALIDATION files
- Full 25-round versions of Task 1 epsilon=none cells for alpha=10 and alpha=0.7 (currently rounds 24-25 and 22-25 only)
- E1 / E4 / E8 manifests; centralized-training script; Table 1 aggregation
- Full test + compile log on one clean commit, with the commit SHA
- Supervisor approval of deviations D1-D5 (paste the message in the issue thread)
